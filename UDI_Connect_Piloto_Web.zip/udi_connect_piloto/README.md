# UDI Connect — piloto web

Aplicación web de prueba para cruzar referencias de fabricante en un Excel con UDI-DI de la API pública EUDAMED.

## Ejecutar gratis en tu ordenador

1. Instala Python 3.11 o superior.
2. Abre una terminal dentro de esta carpeta.
3. Ejecuta `pip install -r requirements.txt`.
4. Ejecuta `streamlit run app.py`.
5. Se abrirá la aplicación en el navegador; sube `ultradent_355.xlsx`.
6. Valores predeterminados: SRN `US-MF-000013697`, referencia columna C, UDI columna D, observaciones columna G, filas 2–356.

## Publicar como página web

Sube la carpeta a un repositorio privado de GitHub y publícala con Streamlit Community Cloud seleccionando `app.py`. Comprueba las condiciones vigentes de su plan gratuito y la privacidad de datos antes de publicar archivos de trabajo. En un despliegue público, configura autenticación y protección de archivos.

## Precauciones regulatorias

- El servicio EUDAMED Data Lake puede ir por detrás del registro en vivo.
- La API limita las respuestas a 1.000 filas: el piloto consulta por referencia si el fabricante alcanza ese límite.
- Solo rellena automáticamente cuando una referencia tiene un único `PRIMARY_DI` confirmado y coincide el SRN.
- Múltiples UDI-DI para la misma referencia se marcan para revisión, sin escoger arbitrariamente uno.
- «Sin coincidencia» no significa que el producto no exista en EUDAMED.
- Un fallo de conexión queda marcado como «Error de consulta», no como «Sin coincidencia».
- Se recomienda revisión humana de los resultados antes de AEMPS.
- La consulta no se ejecuta hasta pulsar el botón y disponer de conectividad desde el servidor web.

API: https://api.datalake.sante.service.ec.europa.eu/eudamed/udi
Guía: https://webgate.ec.europa.eu/eudamed-help/en/files/Public%20API%20-%20user%20guide.pdf
